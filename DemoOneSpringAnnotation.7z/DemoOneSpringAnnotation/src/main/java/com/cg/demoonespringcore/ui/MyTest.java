package com.cg.demoonespringcore.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.demoonespringcore.dto.Item;
import com.cg.demoonespringcore.dto.Product;

public class MyTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");
	Product p=(Product) app.getBean("prod");
	/*p.setId(101);
	p.setName("abcd");
	p.setPrice(10002.0);
	p.setDescription("Videocon...");*/
	
   p.getAllData();
   
  /* Item ip=(Item) app.getBean("it");
   ip.getData();*/
   
   
 
	}

}
