package com.cg.demoonespringcore.dto;

public class Transaction {
private int id;
private double Amount;
private String description;
@Override
public String toString() {
	return "Transaction [id=" + id + ", Amount=" + Amount + ", description=" + description + "]";
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public double getAmount() {
	return Amount;
}
public void setAmount(double amount) {
	Amount = amount;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public Transaction(int id, double amount, String description) {
	super();
	this.id = id;
	Amount = amount;
	this.description = description;
}
public Transaction() {
	super();
	// TODO Auto-generated constructor stub
}
}
