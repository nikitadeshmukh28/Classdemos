package com.cg.ProjectSpringBoot.controller;

import java.util.ArrayList;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cg.ProjectSpringBoot.dto.Game;
import com.cg.ProjectSpringBoot.dto.Player;
import com.cg.ProjectSpringBoot.exception.GameException;
import com.cg.ProjectSpringBoot.exception.PlayerException;
import com.cg.ProjectSpringBoot.service.GameService;
import com.cg.ProjectSpringBoot.service.PlayerService;
@RestController
@RequestMapping("/player")

public class MyController {
	@Autowired
	PlayerService playerservice;
	@Autowired
	GameService gameservice;
	
	@RequestMapping(value = "/addgame", method = RequestMethod.POST)
	public ResponseEntity<Game> addGame(@RequestBody Game gm) {
		System.out.println(gm);
		Game gms=gameservice.save(gm);
		
		return new ResponseEntity<Game>(gms,HttpStatus.OK);
	}
	
	
	
	@RequestMapping(value = "/addplayer", method = RequestMethod.POST)
 public ResponseEntity<Player> addAll(@RequestBody Player pl){
		List<Game> games=new ArrayList<Game>();
Player pls=playerservice.addPlayer(pl);
 Game g=gameservice.findByName(pls.getSkill());
 
	 List<Player> plist=g.getMyplayerlist();
	 plist.add(pls);
	 g.setMyplayerlist(plist);
	// gameservice.save(g);
 
	
		return new ResponseEntity<Player>(pls,HttpStatus.OK);
	}
	 
    
	
	
	
	@RequestMapping(value = "/searchplayerId", method = RequestMethod.POST)
	public ResponseEntity<Player> searchPlayer(@RequestParam ("id") int id) {
		Player p=playerservice.searchById(id);
		
		return new ResponseEntity<Player>(p,HttpStatus.OK);

	}

	
	
	@RequestMapping(value = "/searchpskill", method = RequestMethod.POST)
	public ResponseEntity<List<Player>> searchskill(@RequestParam ("skill") String skill) {
		List<Player> myList = playerservice.searchBySkill(skill);
	
		
		return new ResponseEntity<List<Player>>(myList,HttpStatus.OK);

	}
	
	
	
	@RequestMapping(value = "/searchgname", method = RequestMethod.POST)
	public ResponseEntity<Game> searchgame(@RequestParam ("game") String gamename) {
		Game gm=gameservice.findByName(gamename);
		
		return new ResponseEntity<Game>(gm,HttpStatus.OK);

	}
	
	@RequestMapping(value = "/showplayer", method = RequestMethod.GET)
	public ResponseEntity<List<Player>> showAllPlayer() {
		List<Player> myList = playerservice.show();
		
		
		return new ResponseEntity<List<Player>>(myList,HttpStatus.OK);

	}
	
	
	
	@RequestMapping(value = "/showgames", method = RequestMethod.GET)
	public ResponseEntity<List<Game>> showAllGame() {
		List<Game> myList = gameservice.showAll();
	
		
		return new ResponseEntity<List<Game>>(myList,HttpStatus.OK);

	}
	
		@ExceptionHandler({GameException.class})
			public ResponseEntity handleGameException(GameException error) {
				return  new ResponseEntity(error.getMessage(),HttpStatus.NOT_FOUND);

			}  
		 
		 

		@ExceptionHandler({PlayerException.class})
		public ResponseEntity handlePlayerException(PlayerException error) {
			return  new ResponseEntity(error.getMessage(),HttpStatus.NOT_FOUND);

		}  
	
}
