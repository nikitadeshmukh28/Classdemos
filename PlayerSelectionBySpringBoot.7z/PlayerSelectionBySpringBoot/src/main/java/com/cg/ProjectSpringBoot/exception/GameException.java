package com.cg.ProjectSpringBoot.exception;

public class GameException extends RuntimeException {
	public GameException() {
		super();
	}

	public GameException(String msg) {
		super(msg);
	}
}

