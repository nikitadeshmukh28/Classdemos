package com.cg.ProjectSpringBoot.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ProjectSpringBoot.dao.PlayerDao;
import com.cg.ProjectSpringBoot.dto.Player;
import com.cg.ProjectSpringBoot.exception.PlayerException;
@Service
public class PlayerServiceImpl implements PlayerService {
	static final Logger logger = Logger.getLogger(PlayerServiceImpl.class); 	 
	@Autowired
	PlayerDao playerdao;

	@Override
	public Player addPlayer(Player p) {
		PropertyConfigurator.configure("D:\\Users\\PlayerSelectionBySpringBoot\\src\\main\\resources\\log4j.properties");
		// TODO Auto-generated method stub
		Player ps=playerdao.findByPlayerId(p.getPlayerId());
		if(ps==null) {
		playerdao.save(p);}
		else {
			logger.warn("add player method throws exception for duplicate id"); 
			throw new PlayerException("Player id Already Exist,try with another id");
		}
		logger.info("Player added successful"); 
		return p;
	}

	@Override
	public Player searchById(int playerId) {
		PropertyConfigurator.configure("D:\\Users\\PlayerSelectionBySpringBoot\\src\\main\\resources\\log4j.properties");
		// TODO Auto-generated method stub
		Player p=playerdao.findByPlayerId(playerId);
		if(p==null) {
			logger.warn("player with that id is not found"); 
			throw new PlayerException("Player For This id is Not Found");
		}
		logger.info("Player search method executed successfully"); 
		return p;
	}

	@Override
	public List<Player> searchBySkill(String skill) {
		PropertyConfigurator.configure("D:\\Users\\PlayerSelectionBySpringBoot\\src\\main\\resources\\log4j.properties");
		// TODO Auto-generated method stub
		List<Player> ps=playerdao.findBySkill(skill);
		if(ps.isEmpty()) {
			logger.warn("players with that skill are not found"); 
			throw new PlayerException("Player For This Skill is Not Found");
		}
		logger.info("Player searchBySkill method executed successfully"); 
		return ps;
	}

	@Override
	public List<Player> show() {
		PropertyConfigurator.configure("D:\\Users\\PlayerSelectionBySpringBoot\\src\\main\\resources\\log4j.properties");
		// TODO Auto-generated method stub
		List<Player> ps=playerdao.findAll();
		if(ps.isEmpty()) {
			logger.warn("players not found for display"); 
			throw new PlayerException("Player is not present to show");
		}
		logger.info("Players show All method executed successfully"); 
		return playerdao.findAll();
	}
	
	
	
}
