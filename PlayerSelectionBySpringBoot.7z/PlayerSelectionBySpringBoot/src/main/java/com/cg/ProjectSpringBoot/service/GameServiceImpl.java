package com.cg.ProjectSpringBoot.service;

import java.util.List;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ProjectSpringBoot.dao.GameDao;
import com.cg.ProjectSpringBoot.dto.Game;
import com.cg.ProjectSpringBoot.exception.GameException;
@Service
public class GameServiceImpl implements GameService{
	static final Logger logger = Logger.getLogger(GameServiceImpl.class); 
	@Autowired
    GameDao gamedao;
	@Override
	public Game save(Game game) {
		PropertyConfigurator.configure("D:\\Users\\PlayerSelectionBySpringBoot\\src\\main\\resources\\log4j.properties");
		// TODO Auto-generated method stub
	Game gm=gamedao.findByGameId(game.getGameId());
	if(gm==null) {
		gamedao.save(game);
	}
	else {
		logger.warn("add Game method throws exception for duplicate id"); 
	throw new GameException("Game Id Already Exist,Please try with Another Id");}
	logger.info("Game added successful"); 
	return game;
	
	}

	@Override
	public Game findByName(String name) {
		PropertyConfigurator.configure("D:\\Users\\PlayerSelectionBySpringBoot\\src\\main\\resources\\log4j.properties");
		// TODO Auto-generated method stub
		Game g=gamedao.findByName(name);
		if(g==null) {
			logger.warn("Game with this name is not found");
			throw new GameException("Game with this name is not found");
		}
		logger.info("Game searchbyName method executed successfully"); 
		return g;
		
	}

	@Override
	public List<Game> showAll() {
		PropertyConfigurator.configure("D:\\Users\\PlayerSelectionBySpringBoot\\src\\main\\resources\\log4j.properties");
		List<Game> ps=gamedao.findAll();
		if(ps.isEmpty()) {
			logger.warn("games not found for display"); 
			throw new GameException("Game is not present to show");
			
		}
		logger.info("games show All method executed successfully"); 
		return gamedao.findAll();
	}

	
}
