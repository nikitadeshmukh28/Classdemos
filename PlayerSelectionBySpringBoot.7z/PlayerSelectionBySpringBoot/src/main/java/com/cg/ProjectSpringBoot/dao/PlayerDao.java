package com.cg.ProjectSpringBoot.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.cg.ProjectSpringBoot.dto.Player;


public interface PlayerDao extends JpaRepository<Player,Integer>{
	
	public Player findByPlayerId(int playerId);
	public List<Player> findBySkill(String skill);
	
}
