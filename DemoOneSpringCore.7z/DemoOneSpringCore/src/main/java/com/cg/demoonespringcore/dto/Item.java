package com.cg.demoonespringcore.dto;

public class Item {
	
	private int id;
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	private String nameOfShop;
	
    public Item(int id, String nameOfShop) {
		super();
		this.id = id;
		this.nameOfShop = nameOfShop;
	}

	public String getNameOfShop() {
		return nameOfShop;
	}

	public void setNameOfShop(String nameOfShop) {
		this.nameOfShop = nameOfShop;
	}

	public Item(){
	System.out.println("In Item Constructor...");
  }
    
   public void getData() {
	   System.out.println("Hello....");
   }
 }
