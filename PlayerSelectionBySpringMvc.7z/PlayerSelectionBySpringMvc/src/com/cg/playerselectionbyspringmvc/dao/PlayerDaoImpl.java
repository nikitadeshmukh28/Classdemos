package com.cg.playerselectionbyspringmvc.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.playerselectionbyspringmvc.dto.Player;
@Repository
public class PlayerDaoImpl implements PlayerDao{

	List<Player> playerList=new ArrayList<Player>();
	@Override
	public boolean save(Player p) {
		// TODO Auto-generated method stub
		playerList.add(p);
		return true;
	}

	@Override
	public List<Player> findbyskill(String skill) {
		List<Player> playersearch = new ArrayList<Player>();
		for (Player p :playerList) {
			if (p.getSkill().equals(skill)) {
				playersearch.add(p);
			}
		}
		/**
		 * if player is not found method will throw exception.
		 *
		 * 
		 */ 
		/*if (playersearch.isEmpty()) {
			throw new PlayerException("Player not found for this skill");
		}*/
		return playersearch;
	}

	@Override
	public Player findById(int playerId) {
			for (Player ps : playerList)
				if (ps.getPlayerId() == (playerId))
					return ps;
			return null;
		}

	@Override
	public List<Player> showAllPlayer() {
		// TODO Auto-generated method stub
		return playerList;
	}

	
	}


