package com.cg.playerselectionbyspringmvc.dao;

import java.util.List;

import com.cg.playerselectionbyspringmvc.dto.Game;

public interface GameDao {
	public boolean save(Game game);

	public List<Game> findByName(String name)/* throws GameException */;

	public List<Game> findAll();
}
