package com.cg.playerselectionbyspringmvc.dao;


import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.playerselectionbyspringmvc.dto.Game;
@Repository
public class GameDaoImpl implements GameDao{
List<Game> games=new ArrayList<Game>();
	@Override
	public boolean save(Game game) {
		// TODO Auto-generated method stub
		games.add(game);
		return true;
	}

	@Override
	public List<Game> findByName(String name) {
		List<Game> gamesearch = new ArrayList<Game>();
		for (Game game : games ) {
			if (game.getName().equals(name)) {
				gamesearch.add(game);
			}
		}
		return gamesearch;
		
	}

	@Override
	public List<Game> findAll() {
		// TODO Auto-generated method stub
		return games;
	}

}
