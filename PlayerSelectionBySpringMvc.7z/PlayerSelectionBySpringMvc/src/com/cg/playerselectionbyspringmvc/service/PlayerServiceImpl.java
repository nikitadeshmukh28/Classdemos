package com.cg.playerselectionbyspringmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.playerselectionbyspringmvc.dao.PlayerDao;
import com.cg.playerselectionbyspringmvc.dto.Player;
@Service
public class PlayerServiceImpl implements PlayerService{
	@Autowired
	PlayerDao dao;
	@Override
	public Player addPlayer(Player p) {
		// TODO Auto-generated method stub
		dao.save(p);
		return p;
	}

	@Override
	public Player searchById(int playerId) {
		// TODO Auto-generated method stub
		return dao.findById(playerId);
	}

	@Override
	public List<Player> searchBySkill(String skill) {
		// TODO Auto-generated method stub
		return dao.findbyskill(skill);
	}

	@Override
	public List<Player> showAllPlayer() {
		// TODO Auto-generated method stub
		return dao.showAllPlayer();
	}

}
