package com.cg.playerselectionbyspringmvc.service;

import java.util.List;

import com.cg.playerselectionbyspringmvc.dto.Game;


public interface GameService {

	public Game addGame(Game game);

	public List<Game> searchByName(String name) /*throws GameException*/;

	public List<Game> showAll();
}
