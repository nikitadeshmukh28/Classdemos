package com.cg.playerselectionbyspringmvc.service;

import java.util.List;

import com.cg.playerselectionbyspringmvc.dto.Player;

public interface PlayerService {

	public Player addPlayer(Player p);

	public Player searchById(int playerId) /*throws PlayerException*/;

	public List<Player> searchBySkill(String skill) /*throws PlayerException*/;
	public List<Player> showAllPlayer();
}
