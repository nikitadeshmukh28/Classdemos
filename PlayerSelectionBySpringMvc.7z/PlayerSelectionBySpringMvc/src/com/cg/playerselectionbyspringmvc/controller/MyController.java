package com.cg.playerselectionbyspringmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.playerselectionbyspringmvc.dto.Player;
import com.cg.playerselectionbyspringmvc.service.GameService;
import com.cg.playerselectionbyspringmvc.service.PlayerService;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MyController {
	@Autowired
	PlayerService playerService;

	@Autowired
	GameService gameService;
	@RequestMapping(name="login",method=RequestMethod.GET)
	//@GetMapping("login")
	public String loginPage() {
		return "mylogin";

	}

	@PostMapping("checkLogin")
	public String doLogin(@RequestParam("uname") String user, @RequestParam("pwd") String pass) {
		if (user.equals("admin") && pass.equals("123456")) {
			return "listpage";
		} else {
			return "error";
		}

	}

	@GetMapping("addpage")
	public ModelAndView getAddplayer(@ModelAttribute("player") Player p) {

		List<String> listofSkill = new ArrayList<>();
		listofSkill.add("Cricket");
		listofSkill.add("Khokho");
		listofSkill.add("Kabaddi");
		return new ModelAndView("addplayer", "list", listofSkill);

	}

	@GetMapping("showpage")
	public ModelAndView showProduct() {
		List<Player> myAllPlayer = playerService.showAllPlayer();
		return new ModelAndView("showplayer", "list", myAllPlayer);
	}

	@PostMapping("addplayer")
	public ModelAndView addproduct(@ModelAttribute("player") Player p) {
		// System.out.println(pro);
		//Product product = productService.addproduct(pro);
		Player pl=playerService.addPlayer(p);
		return new ModelAndView("listpage", "key", pl);

	}

}
