package com.cg.demomvcspring.dao;

import java.util.List;

import com.cg.demomvcspring.dto.Product;



public interface ProductDao {
	public Product save(Product pro);
	public List<Product> show();
}
