package com.cg.demomvcspring.service;

import java.util.List;

import com.cg.demomvcspring.dto.Product;



public interface ProductService {

	public Product addproduct(Product pro);
	public List<Product> showAll();
}
